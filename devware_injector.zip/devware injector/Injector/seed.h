#pragma once

#define SEED_RAND(x) (srand(x))