#pragma once

#include <string>

std::string rand_str(int);