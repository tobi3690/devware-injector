#pragma once
#define xor_a(x) x
#define xor_w(x) x

void _xor(uint8_t*, int);
uint8_t* _unxor(uint8_t*, int);